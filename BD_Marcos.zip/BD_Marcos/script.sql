-- MySQL Workbench Synchronization
-- Generated: 2026-04-16 00:45
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: luqui

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `db_estudos` DEFAULT CHARACTER SET utf8 ;

CREATE TABLE IF NOT EXISTS `db_estudos`.`Aluno` (
  `idAluno` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `matricula` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idAluno`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `db_estudos`.`Turma` (
  `idTurma` INT(11) NOT NULL AUTO_INCREMENT,
  `codigoTurma` VARCHAR(45) NOT NULL,
  `semestre` INT(11) NOT NULL,
  `idDisciplina` INT(11) NOT NULL,
  `idProfessor` INT(11) NOT NULL,
  PRIMARY KEY (`idTurma`),
  INDEX `FK_turma_disciplina_idx` (`idDisciplina` ASC) VISIBLE,
  INDEX `FK_turma_Professor_idx` (`idProfessor` ASC) VISIBLE,
  CONSTRAINT `FK_turma_disciplina`
    FOREIGN KEY (`idDisciplina`)
    REFERENCES `db_estudos`.`Disciplina` (`idDisciplina`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_turma_Professor`
    FOREIGN KEY (`idProfessor`)
    REFERENCES `db_estudos`.`Professores` (`idProfessores`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `db_estudos`.`Professores` (
  `idProfessores` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `codigoProfessor` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idProfessores`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `db_estudos`.`Matricula` (
  `idMatricula` INT(11) NOT NULL AUTO_INCREMENT,
  `notaFinal` FLOAT(11) NOT NULL,
  `idAluno` INT(11) NOT NULL,
  `idTurma` INT(11) NOT NULL,
  PRIMARY KEY (`idMatricula`),
  INDEX `FK_matricula_aluno_idx` (`idAluno` ASC) VISIBLE,
  INDEX `FK_matricula_turma_idx` (`idTurma` ASC) VISIBLE,
  CONSTRAINT `FK_matricula_aluno`
    FOREIGN KEY (`idAluno`)
    REFERENCES `db_estudos`.`Aluno` (`idAluno`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_matricula_turma`
    FOREIGN KEY (`idTurma`)
    REFERENCES `db_estudos`.`Turma` (`idTurma`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `db_estudos`.`Disciplina` (
  `idDisciplina` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cargaHorario` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idDisciplina`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
