INSERT INTO Professores (codigoProfessor, nome) VALUES 
('ADS100', 'Carlos Alberto Silva'), 
('ADS200', 'Ana Beatriz Oliveira'), 
('ADS300', 'Ricardo Ferreira Melo');

INSERT INTO Aluno (nome, matricula, email) VALUES 
('João Pedro Santos', '2024001', 'joao.pedro@email.com.br'),
('Maria Eduarda Costa', '2024002', 'maria.duda@email.com.br'),
('Lucas Oliveira Souza', '2024003', 'lucas.souza@email.com.br');

INSERT INTO Disciplina (nome, cargaHorario) VALUES 
('Banco de Dados I', '80'), 
('Desenvolvimento Web', '60'), 
('Algoritmos e Lógica', '100');

INSERT INTO Turma (semestre, codigoTurma, idProfessor, idDisciplina) VALUES 
(1, 'TURMA-ADS-A', 1, 1), 
(1, 'TURMA-ADS-B', 2, 2), 
(2, 'TURMA-ADS-C', 3, 3);

INSERT INTO Matricula (idAluno, idTurma, notaFinal) VALUES 
(1, 1, 8.5), 
(2, 1, 7.0), 
(3, 2, 9.2);