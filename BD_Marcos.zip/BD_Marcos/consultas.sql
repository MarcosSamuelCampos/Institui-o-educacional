SELECT 
    A.nome AS 'Aluno',
    D.nome AS 'Disciplina',
    P.nome AS 'Professor',
    T.codigoTurma AS 'Turma',
    M.notaFinal AS 'Nota'
FROM Aluno A
JOIN Matricula M ON A.idAluno = M.idAluno
JOIN Turma T ON M.idTurma = T.idTurma
JOIN Disciplina D ON T.idDisciplina = D.idDisciplina
JOIN Professores P ON T.idProfessor = P.idProfessores
ORDER BY A.nome;

SELECT 
    T.codigoTurma AS 'Turma',
    A.nome AS 'Nome do Aluno',
    A.matricula AS 'Matrícula'
FROM Turma T
JOIN Matricula M ON T.idTurma = M.idTurma
JOIN Aluno A ON M.idAluno = A.idAluno
WHERE T.codigoTurma = 'TURMA-ADS-A';

SELECT 
    D.nome AS 'Disciplina',
    COUNT(M.idAluno) AS 'Total de Alunos'
FROM Disciplina D
JOIN Turma T ON D.idDisciplina = T.idDisciplina
JOIN Matricula M ON T.idTurma = M.idTurma
GROUP BY D.nome;

SELECT 
    P.nome AS 'Professor',
    AVG(M.notaFinal) AS 'Média de Notas'
FROM Professores P
JOIN Turma T ON P.idProfessores = T.idProfessor
JOIN Matricula M ON T.idTurma = M.idTurma
GROUP BY P.nome;
